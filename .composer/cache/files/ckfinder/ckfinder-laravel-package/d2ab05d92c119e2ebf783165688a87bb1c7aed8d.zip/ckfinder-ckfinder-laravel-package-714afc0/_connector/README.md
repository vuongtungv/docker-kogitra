This directory will contain the CKFinder 3 PHP connector code.

Please run the following command to fill it:

```bash
artisan ckfinder:download
```
